import { Ingredient, Dish } from "./types";

export const INITIAL_INGREDIENTS: Ingredient[] = [
  // Proteins
  { id: "ing_ribeye", name: "Prime Ribeye Beef", unit: "kg", costPerUnit: 42.00, category: "Proteins" },
  { id: "ing_chicken", name: "Free-Range Chicken Breast", unit: "kg", costPerUnit: 11.50, category: "Proteins" },
  { id: "ing_salmon", name: "Fresh Atlantic Salmon Fillet", unit: "kg", costPerUnit: 28.00, category: "Proteins" },
  { id: "ing_prawns", name: "Wild Tiger Prawns", unit: "kg", costPerUnit: 32.00, category: "Proteins" },
  
  // Produce
  { id: "ing_spinach", name: "Organic Baby Spinach", unit: "kg", costPerUnit: 8.50, category: "Produce" },
  { id: "ing_mushrooms", name: "Foraged Wild Mushrooms", unit: "kg", costPerUnit: 18.00, category: "Produce" },
  { id: "ing_tomatoes", name: "Heirloom Vine Tomatoes", unit: "kg", costPerUnit: 6.20, category: "Produce" },
  { id: "ing_garlic", name: "Organic Garlic Cloves", unit: "kg", costPerUnit: 5.00, category: "Produce" },
  { id: "ing_herbs", name: "Fresh Herb Bouquet (Rosemary/Thyme)", unit: "kg", costPerUnit: 15.00, category: "Produce" },
  
  // Dairy
  { id: "ing_parm", name: "Aged Parmigiano-Reggiano", unit: "kg", costPerUnit: 24.50, category: "Dairy" },
  { id: "ing_cream", name: "Premium Double Cream", unit: "liter", costPerUnit: 6.50, category: "Dairy" },
  { id: "ing_butter", name: "Grass-Fed Unsalted Butter", unit: "kg", costPerUnit: 9.80, category: "Dairy" },
  
  // Pantry
  { id: "ing_truffle", name: "White Truffle Oil (Premium)", unit: "liter", costPerUnit: 160.00, category: "Pantry" },
  { id: "ing_gnocchi", name: "Artisanal Gnocchi Pasta", unit: "kg", costPerUnit: 7.50, category: "Pantry" },
  { id: "ing_olive_oil", name: "Extra Virgin Olive Oil", unit: "liter", costPerUnit: 14.00, category: "Pantry" },
  { id: "ing_rice", name: "Aromatic Jasmine Rice", unit: "kg", costPerUnit: 3.20, category: "Pantry" },
  { id: "ing_cocoa", name: "Organic Belgian Cocoa", unit: "kg", costPerUnit: 22.00, category: "Pantry" },
  { id: "ing_vanilla", name: "Madagascar Vanilla Beans", unit: "kg", costPerUnit: 280.00, category: "Pantry" },
  
  // Garnish
  { id: "ing_gold", name: "24K Edible Gold Flakes", unit: "g", costPerUnit: 95.00, category: "Garnish" },
  { id: "ing_microgreens", name: "Zesty Microgreen Shoots", unit: "kg", costPerUnit: 40.00, category: "Garnish" },
];

export const INITIAL_DISHES: Dish[] = [
  {
    id: "dish_gnocchi",
    name: "Truffle Gnocchi Supreme",
    description: "Pan-pillowed artisanal gnocchi bathed in premium double cream, infused with exquisite white truffle oil, and showered with aged parmigiano-reggiano. Garnished with microgreen shoots.",
    category: "Appetizers",
    menuPrice: 24.00,
    ingredients: [
      { ingredientId: "ing_gnocchi", amount: 0.20 }, // 200g -> $1.50
      { ingredientId: "ing_truffle", amount: 0.015 }, // 15ml -> $2.40
      { ingredientId: "ing_parm", amount: 0.035 }, // 35g -> $0.86
      { ingredientId: "ing_cream", amount: 0.08 }, // 80ml -> $0.52
      { ingredientId: "ing_butter", amount: 0.02 }, // 20g -> $0.20
      { ingredientId: "ing_microgreens", amount: 0.002 }, // 2g -> $0.08
    ],
    dietaryTags: ["Vegetarian", "Signature"],
    imageUrl: "https://images.unsplash.com/photo-1645112411341-6c4fd023714a?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_tomahawk",
    name: "24K Golden Sovereign Ribeye",
    description: "A colossal, dry-aged Prime Ribeye steak pan-basted in rosemary-infused grass-fed butter, delicately draped with 24-karat edible gold flakes for ultimate culinary luxury.",
    category: "Mains",
    menuPrice: 85.00,
    ingredients: [
      { ingredientId: "ing_ribeye", amount: 0.45 }, // 450g -> $18.90
      { ingredientId: "ing_gold", amount: 0.15 }, // 0.15g -> $14.25
      { ingredientId: "ing_butter", amount: 0.05 }, // 50g -> $0.49
      { ingredientId: "ing_herbs", amount: 0.02 }, // 20g -> $0.30
      { ingredientId: "ing_garlic", amount: 0.01 }, // 10g -> $0.05
    ],
    dietaryTags: ["Gluten-Free", "Chef's Special"],
    imageUrl: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_salmon",
    name: "Pan-Seared Atlantic Salmon",
    description: "Crispy-skin Atlantic salmon resting on a bed of seasoned organic baby spinach, drizzled with premium extra virgin olive oil and fresh lemon herb reduction.",
    category: "Mains",
    menuPrice: 36.00,
    ingredients: [
      { ingredientId: "ing_salmon", amount: 0.22 }, // 220g -> $6.16
      { ingredientId: "ing_spinach", amount: 0.12 }, // 120g -> $1.02
      { ingredientId: "ing_olive_oil", amount: 0.025 }, // 25ml -> $0.35
      { ingredientId: "ing_herbs", amount: 0.015 }, // 15g -> $0.23
      { ingredientId: "ing_butter", amount: 0.015 }, // 15g -> $0.15
    ],
    dietaryTags: ["Gluten-Free", "Heart Healthy"],
    imageUrl: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_chicken",
    name: "Rosemary Butter Chicken Breast",
    description: "Tender pan-roasted free-range chicken breast served over fluffy aromatic jasmine rice, accompanied by a decadent rosemary double cream pan-reduction.",
    category: "Mains",
    menuPrice: 28.00,
    ingredients: [
      { ingredientId: "ing_chicken", amount: 0.22 }, // 220g -> $2.53
      { ingredientId: "ing_rice", amount: 0.10 }, // 100g dry -> $0.32
      { ingredientId: "ing_cream", amount: 0.06 }, // 60ml -> $0.39
      { ingredientId: "ing_butter", amount: 0.025 }, // 25g -> $0.25
      { ingredientId: "ing_herbs", amount: 0.01 }, // 10g -> $0.15
    ],
    dietaryTags: ["Nut-Free"],
    imageUrl: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_arancini",
    name: "Heirloom Tomato Arancini",
    description: "Golden-crisped risotto croquettes stuffed with rich aged parmigiano-reggiano cheese, served over a vibrant heirloom vine tomato reduction with fresh torn basil leaves.",
    category: "Appetizers",
    menuPrice: 15.00,
    ingredients: [
      { ingredientId: "ing_rice", amount: 0.08 }, // 80g -> $0.26
      { ingredientId: "ing_parm", amount: 0.03 }, // 30g -> $0.74
      { ingredientId: "ing_tomatoes", amount: 0.12 }, // 120g -> $0.74
      { ingredientId: "ing_olive_oil", amount: 0.015 }, // 15ml -> $0.21
      { ingredientId: "ing_garlic", amount: 0.005 }, // 5g -> $0.03
    ],
    dietaryTags: ["Vegetarian"],
    imageUrl: "https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_pannacotta",
    name: "Madagascar Bourbon Vanilla Panna Cotta",
    description: "Silky, chilled sweet cream gelatin infused with real bourbon vanilla seeds from premium Madagascar beans, complemented by a splash of fresh summer berry glaze.",
    category: "Desserts",
    menuPrice: 12.00,
    ingredients: [
      { ingredientId: "ing_cream", amount: 0.12 }, // 120ml -> $0.78
      { ingredientId: "ing_vanilla", amount: 0.004 }, // 4g bean -> $1.12
      { ingredientId: "ing_tomatoes", amount: 0.02 }, // proxy for berry garnish -> $0.12
    ],
    dietaryTags: ["Gluten-Free", "Signature Dessert"],
    imageUrl: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=800",
  },
  {
    id: "dish_chocolate_tart",
    name: "Belgian Cocoa Ganache Tart",
    description: "A crumbly, buttery pastry shell filled with decadent Belgian chocolate cream, lightly dusted with fine cocoa powder and finished with a delicate fleck of 24K gold.",
    category: "Desserts",
    menuPrice: 14.00,
    ingredients: [
      { ingredientId: "ing_cocoa", amount: 0.05 }, // 50g cocoa -> $1.10
      { ingredientId: "ing_butter", amount: 0.03 }, // 30g pastry butter -> $0.29
      { ingredientId: "ing_cream", amount: 0.05 }, // 50ml -> $0.33
      { ingredientId: "ing_gold", amount: 0.005 }, // 0.005g -> $0.48
    ],
    dietaryTags: ["Vegetarian"],
    imageUrl: "https://images.unsplash.com/photo-1508737027454-e6454ef45afd?auto=format&fit=crop&q=80&w=800",
  }
];
