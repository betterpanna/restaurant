export interface Ingredient {
  id: string;
  name: string;
  unit: string;
  costPerUnit: number; // current market cost
  category: "Proteins" | "Produce" | "Pantry" | "Dairy" | "Garnish";
}

export interface DishIngredient {
  ingredientId: string;
  amount: number; // quantity of unit needed
}

export interface Dish {
  id: string;
  name: string;
  description: string;
  category: "Appetizers" | "Mains" | "Desserts" | "Drinks";
  menuPrice: number; // what customers pay
  ingredients: DishIngredient[]; // recipe ingredients
  dietaryTags: string[]; // e.g. "Vegan", "Gluten-Free", "Chef Spec"
  imageUrl: string;
}

export interface Reservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  specialRequests?: string;
  status: "Confirmed" | "Pending" | "Cancelled";
  tableNumber?: number;
}

export interface OrderItem {
  id: string;
  dishId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface AIAdvisorResponse {
  analysis: string;
  suggestions: {
    dishId: string;
    dishName: string;
    currentCost: number;
    currentMargin: number;
    recommendedPrice: number;
    action: string;
    details: string;
  }[];
  marketOutlook: string;
}
