import React, { useState, useMemo } from "react";
import { Ingredient, Dish } from "../types";
import { 
  TrendingUp, 
  Percent, 
  DollarSign, 
  RotateCcw, 
  Sliders, 
  Zap, 
  AlertTriangle, 
  CheckCircle,
  HelpCircle,
  TrendingDown
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from "recharts";

interface PricingDashboardProps {
  ingredients: Ingredient[];
  dishes: Dish[];
  updateIngredientCost: (id: string, newCost: number) => void;
  updateDishMenuPrice: (id: string, newPrice: number) => void;
  resetAllCosts: () => void;
  applyEconomicShock: (multiplier: number, category?: string) => void;
}

export default function PricingDashboard({
  ingredients,
  dishes,
  updateIngredientCost,
  updateDishMenuPrice,
  resetAllCosts,
  applyEconomicShock,
}: PricingDashboardProps) {
  const [activeCategory, setActiveCategory] = useState<"All" | "Proteins" | "Produce" | "Dairy" | "Pantry" | "Garnish">("All");

  const categories = ["All", "Proteins", "Produce", "Dairy", "Pantry", "Garnish"];

  const filteredIngredients = useMemo(() => {
    return activeCategory === "All"
      ? ingredients
      : ingredients.filter((ing) => ing.category === activeCategory);
  }, [ingredients, activeCategory]);

  // Compute recipe costs and margins for dishes
  const calculatedDishes = useMemo(() => {
    return dishes.map((dish) => {
      // Calculate total food cost for this dish based on current ingredient costs
      const recipeCost = dish.ingredients.reduce((total, recipeIng) => {
        const ingredient = ingredients.find((ing) => ing.id === recipeIng.ingredientId);
        if (!ingredient) return total;
        return total + (ingredient.costPerUnit * recipeIng.amount);
      }, 0);

      const foodCostPercentage = dish.menuPrice > 0 ? (recipeCost / dish.menuPrice) * 100 : 0;
      const profitMarginDollar = dish.menuPrice - recipeCost;
      const profitMarginPercentage = dish.menuPrice > 0 ? (profitMarginDollar / dish.menuPrice) * 100 : 0;

      return {
        ...dish,
        recipeCost,
        foodCostPercentage,
        profitMarginDollar,
        profitMarginPercentage,
      };
    });
  }, [dishes, ingredients]);

  // General financial summary stats
  const stats = useMemo(() => {
    const totalMenuPrice = calculatedDishes.reduce((sum, d) => sum + d.menuPrice, 0);
    const totalRecipeCost = calculatedDishes.reduce((sum, d) => sum + d.recipeCost, 0);
    const averageFoodCostPercentage = calculatedDishes.length > 0 
      ? (totalRecipeCost / totalMenuPrice) * 100 
      : 0;
    
    const worstDish = [...calculatedDishes].sort((a, b) => b.foodCostPercentage - a.foodCostPercentage)[0];
    const bestDish = [...calculatedDishes].sort((a, b) => a.foodCostPercentage - b.foodCostPercentage)[0];

    return {
      averageFoodCost: averageFoodCostPercentage,
      totalRecipeCost,
      totalRevenuePotential: totalMenuPrice,
      worstDish,
      bestDish,
    };
  }, [calculatedDishes]);

  // Chart data formatting
  const chartData = useMemo(() => {
    return calculatedDishes.map((dish) => ({
      name: dish.name.length > 15 ? dish.name.slice(0, 15) + "..." : dish.name,
      "Menu Price ($)": parseFloat(dish.menuPrice.toFixed(2)),
      "Recipe Cost ($)": parseFloat(dish.recipeCost.toFixed(2)),
      "Gross profit ($)": parseFloat(dish.profitMarginDollar.toFixed(2)),
      "Food Cost %": parseFloat(dish.foodCostPercentage.toFixed(2)),
    }));
  }, [calculatedDishes]);

  // Helpers for styling threshold values
  const getFoodCostBadge = (percentage: number) => {
    if (percentage < 25) {
      return {
        bg: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20",
        label: "Outstanding (Under 25%)",
        icon: CheckCircle
      };
    } else if (percentage <= 35) {
      return {
        bg: "bg-green-500/10 text-green-300 border-green-500/20",
        label: "Healthy (25% - 35%)",
        icon: CheckCircle
      };
    } else if (percentage <= 45) {
      return {
        bg: "bg-amber-500/10 text-amber-300 border-amber-500/20",
        label: "Warning (35% - 45%)",
        icon: AlertTriangle
      };
    } else {
      return {
        bg: "bg-rose-500/10 text-rose-300 border-rose-500/20",
        label: "Critical (Over 45%)",
        icon: AlertTriangle
      };
    }
  };

  return (
    <div className="space-y-8">
      {/* 1. Header Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-white">
        {/* Metric 1 */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 flex items-center justify-between shadow-sm rounded-2xl">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block">Average Food Cost %</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-2xl font-bold text-white">
                {stats.averageFoodCost.toFixed(1)}%
              </span>
              <span className="text-[10px] text-white/60 font-medium">Target: 30%</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl ${stats.averageFoodCost <= 35 ? "bg-green-500/10 text-green-400" : "bg-amber-500/10 text-amber-400"}`}>
            <Percent className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 flex items-center justify-between shadow-sm rounded-2xl">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block">Lowest Margin Dish</span>
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-white truncate max-w-[150px] block">
                {stats.worstDish?.name}
              </span>
              <span className="font-mono text-xs font-semibold text-rose-400 block">
                Food Cost: {stats.worstDish?.foodCostPercentage.toFixed(1)}%
              </span>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-rose-500/10 text-rose-400">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 flex items-center justify-between shadow-sm rounded-2xl">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block">Highest Margin Dish</span>
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-white truncate max-w-[150px] block">
                {stats.bestDish?.name}
              </span>
              <span className="font-mono text-xs font-semibold text-emerald-400 block">
                Food Cost: {stats.bestDish?.foodCostPercentage.toFixed(1)}%
              </span>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400">
            <TrendingDown className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 flex items-center justify-between shadow-sm rounded-2xl">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-white/40 block">Simulated Profit Index</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-2xl font-bold text-orange-400">
                ${(stats.totalRevenuePotential - stats.totalRecipeCost).toFixed(2)}
              </span>
              <span className="text-[10px] text-white/40 font-medium">/ full menu sweep</span>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-orange-500/10 text-orange-400">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 2. Economic Shocks & Sim Controls */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 text-white rounded-3xl p-6 shadow-md">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1">
            <h4 className="font-serif text-lg font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-orange-400" /> Market Intelligence & Economic Shocks
            </h4>
            <p className="text-white/60 text-xs">
              Simulate dynamic market shifts, inflation bursts, or supply shocks to see immediate downstream effects on recipe profitability.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => applyEconomicShock(1.20)}
              className="bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold px-3 py-2 rounded-xl transition-all cursor-pointer"
              id="shock-inflation"
            >
              +20% Inflation wave
            </button>
            <button
              onClick={() => applyEconomicShock(1.35, "Proteins")}
              className="bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold px-3 py-2 rounded-xl transition-all cursor-pointer"
              id="shock-proteins"
            >
              +35% Protein shortage
            </button>
            <button
              onClick={() => applyEconomicShock(0.85, "Dairy")}
              className="bg-white/5 hover:bg-white/10 text-white border border-white/10 text-xs font-semibold px-3 py-2 rounded-xl transition-all cursor-pointer"
              id="shock-dairy"
            >
              -15% Dairy subsidy
            </button>
            <button
              onClick={resetAllCosts}
              className="bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              id="reset-simulation"
            >
              <RotateCcw className="w-3.5 h-3.5" /> Reset Market
            </button>
          </div>
        </div>
      </div>

      {/* 3. Central Dual-Columns Panel */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        {/* Ingredient Price Adjustment (5 columns) */}
        <div className="xl:col-span-5 bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 space-y-6 text-white">
          <div className="flex justify-between items-center pb-3 border-b border-white/10">
            <h4 className="font-serif text-lg font-bold text-white flex items-center gap-2">
              <Sliders className="w-4.5 h-4.5 text-orange-400" /> Ingredient Costs (BOH)
            </h4>
            <span className="text-[10px] font-mono text-white/40 uppercase">Back of House</span>
          </div>

          {/* Ingredient category tabs */}
          <div className="flex flex-wrap gap-1.5 bg-white/5 border border-white/5 p-1 rounded-xl">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat as any)}
                className={`flex-1 text-[10px] font-semibold py-1.5 rounded-lg transition-all cursor-pointer ${
                  activeCategory === cat
                    ? "bg-white/15 text-orange-400 shadow-xs border border-white/5"
                    : "text-white/60 hover:text-white"
                }`}
                id={`ing-cat-${cat.toLowerCase()}`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Ingredient cost sliders */}
          <div className="space-y-4 max-h-[30rem] overflow-y-auto pr-1">
            {filteredIngredients.map((ing) => (
              <div key={ing.id} className="space-y-2 border-b border-white/5 pb-3 last:border-0 last:pb-0" id={`ing-slider-${ing.id}`}>
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-white/80">{ing.name}</span>
                  <span className="font-mono text-white/40 uppercase tracking-wider text-[10px]">
                    {ing.unit}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={Math.max(0.1, ing.costPerUnit * 0.2).toFixed(2)}
                    max={(ing.costPerUnit * 4).toFixed(2)}
                    step="0.1"
                    value={ing.costPerUnit}
                    onChange={(e) => updateIngredientCost(ing.id, parseFloat(e.target.value))}
                    className="flex-1 accent-orange-500 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                    id={`slider-input-${ing.id}`}
                  />
                  <span className="font-mono text-xs font-bold text-orange-400 bg-white/10 px-2.5 py-1 rounded-lg border border-white/10 w-20 text-right">
                    ${ing.costPerUnit.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Menu Pricing & Profitability Grid (7 columns) */}
        <div className="xl:col-span-7 bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 space-y-6 text-white">
          <div className="flex justify-between items-center pb-3 border-b border-white/10">
            <h4 className="font-serif text-lg font-bold text-white flex items-center gap-2">
              <Percent className="w-4.5 h-4.5 text-orange-400" /> Menu Items Profitability (FOH)
            </h4>
            <span className="text-[10px] font-mono text-white/40 uppercase">Front of House</span>
          </div>

          <div className="space-y-4 max-h-[34rem] overflow-y-auto pr-1">
            {calculatedDishes.map((dish) => {
              const status = getFoodCostBadge(dish.foodCostPercentage);
              const StatusIcon = status.icon;

              return (
                <div 
                  key={dish.id} 
                  className="p-4 border border-white/5 rounded-2xl hover:border-white/10 transition-all duration-200 grid grid-cols-1 md:grid-cols-12 gap-4 items-center"
                  id={`profit-item-${dish.id}`}
                >
                  {/* Dish name & description */}
                  <div className="md:col-span-4 space-y-1">
                    <h5 className="font-serif text-sm font-bold text-white">{dish.name}</h5>
                    <div className="flex items-center gap-1.5">
                      <StatusIcon className="w-3 h-3 text-current" />
                      <span className={`text-[9px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-sm border ${status.bg}`}>
                        {dish.foodCostPercentage.toFixed(0)}% FC
                      </span>
                    </div>
                  </div>

                  {/* Financial inputs and cost labels */}
                  <div className="md:col-span-8 grid grid-cols-3 gap-2 text-center text-xs">
                    {/* Cost of Goods */}
                    <div className="space-y-0.5 bg-white/5 rounded-xl p-2 border border-white/5">
                      <span className="text-[9px] text-white/40 uppercase tracking-wider block">Recipe Cost</span>
                      <span className="font-mono text-xs font-bold text-white/80">
                        ${dish.recipeCost.toFixed(2)}
                      </span>
                    </div>

                    {/* Menu Price Input */}
                    <div className="space-y-0.5 bg-white/10 border border-white/10 rounded-xl p-2">
                      <span className="text-[9px] text-orange-300 uppercase tracking-wider block">Menu Price</span>
                      <div className="flex items-center justify-center font-mono font-bold text-orange-400">
                        <span>$</span>
                        <input
                          type="number"
                          step="0.50"
                          min="1"
                          value={dish.menuPrice}
                          onChange={(e) => updateDishMenuPrice(dish.id, parseFloat(e.target.value) || 0)}
                          className="w-12 bg-transparent text-center focus:outline-hidden text-xs text-orange-400 border-none outline-none"
                          id={`price-input-${dish.id}`}
                        />
                      </div>
                    </div>

                    {/* Profit Margin */}
                    <div className="space-y-0.5 bg-white/5 rounded-xl p-2 border border-white/5">
                      <span className="text-[9px] text-white/40 uppercase tracking-wider block">Gross Profit</span>
                      <span className="font-mono text-xs font-bold text-white/80">
                        ${dish.profitMarginDollar.toFixed(2)}
                        <span className="text-[9px] text-emerald-400 block">
                          ({dish.profitMarginPercentage.toFixed(0)}% margin)
                        </span>
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 4. Chart Visualization (using Recharts) */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 shadow-xs space-y-4 text-white">
        <div className="border-b border-white/10 pb-3">
          <h4 className="font-serif text-lg font-bold text-white">Financial Modeling Chart</h4>
          <p className="text-white/60 text-xs">Comparing Recipe Cost, Menu Price, and simulated Gross Margin ($) across all menu categories.</p>
        </div>

        <div className="h-96 w-full" id="pricing-recharts-container">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 10, left: -10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff10" />
              <XAxis 
                dataKey="name" 
                tick={{ fill: "#ffffff60", fontSize: 10, fontWeight: 500 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis 
                tickFormatter={(val) => `$${val}`}
                tick={{ fill: "#ffffff60", fontSize: 10, fontWeight: 500 }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip 
                formatter={(val: any, name: any) => [`$${val}`, name]}
                contentStyle={{ backgroundColor: "#0e0e0e", borderRadius: "12px", border: "1px solid rgba(255,255,255,0.1)", color: "#ffffff", fontSize: "12px" }}
              />
              <Legend 
                wrapperStyle={{ fontSize: "11px", fontWeight: 500, paddingTop: "15px" }}
              />
              <Bar dataKey="Recipe Cost ($)" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Gross profit ($)" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Menu Price ($)" fill="#f97316" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
