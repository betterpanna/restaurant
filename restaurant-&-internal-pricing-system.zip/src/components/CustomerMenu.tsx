import React, { useState } from "react";
import { Dish, OrderItem } from "../types";
import { Plus, Minus, ShoppingBag, Eye, Heart, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface CustomerMenuProps {
  dishes: Dish[];
  addToOrder: (dish: Dish) => void;
  orderItems: OrderItem[];
  updateOrderQuantity: (id: string, delta: number) => void;
  removeFromOrder: (id: string) => void;
}

export default function CustomerMenu({
  dishes,
  addToOrder,
  orderItems,
  updateOrderQuantity,
  removeFromOrder,
}: CustomerMenuProps) {
  const [selectedCategory, setSelectedCategory] = useState<"All" | "Appetizers" | "Mains" | "Desserts">("All");
  const [selectedDishDetail, setSelectedDishDetail] = useState<Dish | null>(null);

  const categories = ["All", "Appetizers", "Mains", "Desserts"];

  const filteredDishes = selectedCategory === "All"
    ? dishes
    : dishes.filter((dish) => dish.category === selectedCategory);

  const totalOrderPrice = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Menu Column */}
      <div className="lg:col-span-2 space-y-6">
        {/* Category Selector */}
        <div className="flex flex-wrap gap-2 pb-2 border-b border-white/10">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category as any)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 cursor-pointer ${
                selectedCategory === category
                  ? "bg-white/15 text-orange-400 border border-white/10 shadow-md font-semibold"
                  : "bg-white/5 hover:bg-white/10 text-white/60 border border-transparent"
              }`}
              id={`cat-btn-${category.toLowerCase()}`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Dishes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredDishes.map((dish) => {
              const orderItem = orderItems.find((item) => item.dishId === dish.id);
              return (
                <motion.div
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  key={dish.id}
                  className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden shadow-md hover:border-white/20 transition-all duration-300 flex flex-col group"
                  id={`dish-card-${dish.id}`}
                >
                  {/* Dish Image */}
                  <div className="relative h-48 w-full overflow-hidden bg-white/5">
                    <img
                      src={dish.imageUrl}
                      alt={dish.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                      <button
                        onClick={() => setSelectedDishDetail(dish)}
                        className="bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold px-3 py-1.5 rounded-full flex items-center gap-1.5 text-white transition-transform duration-300 hover:scale-105 cursor-pointer shadow-xs"
                      >
                        <Eye className="w-3.5 h-3.5 text-orange-400" /> View Recipe Specs
                      </button>
                    </div>
                    {/* Category Tag */}
                    <span className="absolute top-3 left-3 bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-bold text-orange-300 px-2.5 py-1 rounded-full uppercase tracking-wider shadow-xs">
                      {dish.category}
                    </span>
                  </div>

                  {/* Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start gap-2 mb-2">
                        <h3 className="font-serif text-lg font-semibold text-white group-hover:text-orange-400 transition-colors">
                          {dish.name}
                        </h3>
                        <span className="font-mono text-base font-bold text-orange-400">
                          ${dish.menuPrice.toFixed(2)}
                        </span>
                      </div>
                      <p className="text-white/60 text-xs leading-relaxed mb-4 line-clamp-2">
                        {dish.description}
                      </p>
                    </div>

                    <div className="space-y-4">
                      {/* Dietary Tags */}
                      <div className="flex flex-wrap gap-1.5">
                        {dish.dietaryTags.map((tag) => (
                          <span
                            key={tag}
                            className="bg-white/5 border border-white/5 text-orange-300 text-[10px] font-medium px-2 py-0.5 rounded-md flex items-center gap-1"
                          >
                            <Sparkles className="w-2.5 h-2.5" />
                            {tag}
                          </span>
                        ))}
                      </div>

                      {/* Add Button Section */}
                      <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                        {orderItem ? (
                          <div className="flex items-center gap-3 bg-white/5 border border-white/10 rounded-full px-3 py-1">
                            <button
                              onClick={() => updateOrderQuantity(orderItem.id, -1)}
                              className="w-7 h-7 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors cursor-pointer"
                              id={`minus-btn-${dish.id}`}
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="font-mono text-sm font-semibold text-white">
                              {orderItem.quantity}
                            </span>
                            <button
                              onClick={() => updateOrderQuantity(orderItem.id, 1)}
                              className="w-7 h-7 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors cursor-pointer"
                              id={`plus-btn-${dish.id}`}
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToOrder(dish)}
                            className="w-full bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold py-2 px-4 rounded-xl transition-all duration-300 flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                            id={`add-btn-${dish.id}`}
                          >
                            <Plus className="w-3.5 h-3.5" /> Add to Ticket
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>

      {/* Ticket Column */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 flex flex-col justify-between h-fit sticky top-6">
        <div>
          <div className="flex items-center gap-2 pb-4 border-b border-white/10 mb-4">
            <ShoppingBag className="w-5 h-5 text-orange-400" />
            <h3 className="font-serif text-lg font-bold text-white">Your Guest Ticket</h3>
          </div>

          {orderItems.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-orange-400">
                <ShoppingBag className="w-5 h-5 opacity-60" />
              </div>
              <p className="text-white/60 text-xs">Your dining ticket is currently empty.</p>
              <p className="text-white/40 text-[11px]">Select dishes from our menu to build your virtual guest bill.</p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {orderItems.map((item) => (
                <div key={item.id} className="flex justify-between items-center gap-4 text-sm" id={`ticket-item-${item.id}`}>
                  <div className="space-y-0.5">
                    <span className="font-medium text-white">{item.name}</span>
                    <div className="flex items-center gap-1.5 text-xs text-white/40">
                      <span className="font-mono">${item.price.toFixed(2)}</span>
                      <span>×</span>
                      <span className="font-mono">{item.quantity}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-semibold text-orange-400">
                      ${(item.price * item.quantity).toFixed(2)}
                    </span>
                    <button
                      onClick={() => removeFromOrder(item.id)}
                      className="text-white/40 hover:text-red-400 transition-colors text-xs cursor-pointer"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {orderItems.length > 0 && (
          <div className="pt-6 border-t border-white/10 mt-6 space-y-4">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-white/40">
                <span>Subtotal</span>
                <span className="font-mono text-white/80">${totalOrderPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-white/40">
                <span>Simulated Tax (8%)</span>
                <span className="font-mono text-white/80">${(totalOrderPrice * 0.08).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-white/40">
                <span>Simulated Service Charge (15%)</span>
                <span className="font-mono text-white/80">${(totalOrderPrice * 0.15).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-white/10">
                <span>Total Bill</span>
                <span className="font-mono text-orange-400">${(totalOrderPrice * 1.23).toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => {
                // Modified from alert to a beautiful custom message or window safe call
                console.log("Simulating Checkout...");
              }}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-xl text-xs transition-all duration-300 text-center cursor-pointer shadow-md"
            >
              Simulate Checkout
            </button>
          </div>
        )}
      </div>

      {/* Recipe Specs Modal */}
      <AnimatePresence>
        {selectedDishDetail && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#0e0e0e] border border-white/10 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl"
            >
              <div className="h-48 bg-white/5 relative">
                <img
                  src={selectedDishDetail.imageUrl}
                  alt={selectedDishDetail.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setSelectedDishDetail(null)}
                  className="absolute top-4 right-4 bg-black/60 hover:bg-black/80 text-white w-8 h-8 rounded-full flex items-center justify-center cursor-pointer transition-colors border border-white/10"
                >
                  ×
                </button>
              </div>
              <div className="p-6 space-y-4 text-white">
                <div>
                  <div className="flex justify-between items-baseline mb-1">
                    <h4 className="font-serif text-xl font-bold text-white">{selectedDishDetail.name}</h4>
                    <span className="font-mono font-bold text-orange-400 text-lg">${selectedDishDetail.menuPrice.toFixed(2)}</span>
                  </div>
                  <span className="bg-white/10 text-orange-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider border border-white/5">
                    {selectedDishDetail.category}
                  </span>
                </div>

                <p className="text-white/60 text-xs leading-relaxed">{selectedDishDetail.description}</p>

                <div className="pt-4 border-t border-white/10">
                  <h5 className="font-semibold text-white text-xs uppercase tracking-wider mb-2">Recipe Cost Breakdown</h5>
                  <div className="bg-white/5 border border-white/5 rounded-xl p-3 space-y-1.5 text-xs">
                    <p className="text-white/60">
                      This dish is crafted with carefully sourced, premium ingredients.
                    </p>
                    <p className="text-white/80 font-medium">
                      Portion Sizes & Ingredients:
                    </p>
                    <ul className="list-disc list-inside text-[11px] text-white/40 space-y-1 pl-1">
                      {selectedDishDetail.ingredients.map((ing, i) => (
                        <li key={i}>
                          Recipe quantity: <span className="font-mono text-white/80 font-semibold">{ing.amount} units</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-2 flex justify-end">
                  <button
                    onClick={() => {
                      addToOrder(selectedDishDetail);
                      setSelectedDishDetail(null);
                    }}
                    className="bg-orange-500 hover:bg-orange-600 text-white px-5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all duration-300 shadow-md"
                  >
                    Add to Ticket
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
