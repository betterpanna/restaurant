import React, { useState, useEffect } from "react";
import { Reservation } from "../types";
import { Calendar, Users, Clock, HelpCircle, CheckCircle, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ReservationFormProps {
  reservations: Reservation[];
  addReservation: (res: Omit<Reservation, "id" | "status" | "tableNumber">) => void;
  cancelReservation: (id: string) => void;
}

export default function ReservationForm({
  reservations,
  addReservation,
  cancelReservation,
}: ReservationFormProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("19:00");
  const [specialRequests, setSpecialRequests] = useState("");
  const [submitted, setSubmitted] = useState(false);

  // Set default date to tomorrow
  useEffect(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setDate(tomorrow.toISOString().split("T")[0]);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !date || !time) return;

    addReservation({
      name,
      email,
      phone,
      guests,
      date,
      time,
      specialRequests: specialRequests.trim() || undefined,
    });

    // Reset Form
    setName("");
    setEmail("");
    setPhone("");
    setGuests(2);
    setSpecialRequests("");
    setSubmitted(true);

    setTimeout(() => {
      setSubmitted(false);
    }, 5000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      {/* Booking Form (3 Columns) */}
      <div className="lg:col-span-3 bg-white/5 backdrop-blur-md border border-white/10 p-6 md:p-8 shadow-xs rounded-3xl text-white">
        <h3 className="font-serif text-2xl font-bold text-white mb-2">Reserve Your Table</h3>
        <p className="text-white/60 text-xs mb-6">
          Experience gourmet dining custom-tailored to your culinary desires. Please complete the form below.
        </p>

        <AnimatePresence mode="wait">
          {submitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6 text-center space-y-4 py-12"
              id="reservation-success-alert"
            >
              <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center mx-auto shadow-md">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="font-serif text-lg font-bold text-emerald-400">Reservation Submitted!</h4>
                <p className="text-emerald-300 text-xs max-w-sm mx-auto leading-relaxed">
                  We've received your table request. A reservation confirmation has been prepared and sent to your email.
                </p>
              </div>
              <button
                onClick={() => setSubmitted(false)}
                className="text-xs font-semibold text-emerald-400 underline hover:text-emerald-300 cursor-pointer"
              >
                Book Another Table
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5" id="booking-form">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Full Name */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60 block">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/20 focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200"
                    placeholder="E.g., Charlotte Sterling"
                    id="res-name"
                  />
                </div>

                {/* Email Address */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60 block">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/20 focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200"
                    placeholder="E.g., charlotte@example.com"
                    id="res-email"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Phone */}
                <div className="space-y-1 md:col-span-1">
                  <label className="text-xs font-semibold text-white/60 block">Contact Phone</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/20 focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200"
                    placeholder="(555) 019-2834"
                    id="res-phone"
                  />
                </div>

                {/* Guests count */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60 block">Guests Count</label>
                  <div className="relative">
                    <Users className="absolute left-3.5 top-3 w-4 h-4 text-white/40 pointer-events-none" />
                    <select
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                      className="w-full bg-[#151515] border border-white/10 text-white rounded-xl pl-10 pr-4 py-2.5 text-xs focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200 appearance-none"
                      id="res-guests"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 10, 12].map((num) => (
                        <option key={num} value={num} className="bg-[#151515] text-white">
                          {num} {num === 1 ? "Guest" : "Guests"}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date Selection */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60 block">Select Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3.5 top-3 w-4 h-4 text-white/40 pointer-events-none" />
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200"
                      id="res-date"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Time Slot */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60 block">Preferred Time</label>
                  <div className="relative">
                    <Clock className="absolute left-3.5 top-3 w-4 h-4 text-white/40 pointer-events-none" />
                    <select
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full bg-[#151515] border border-white/10 text-white rounded-xl pl-10 pr-4 py-2.5 text-xs focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200 appearance-none"
                      id="res-time"
                    >
                      {["17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00"].map((slot) => (
                        <option key={slot} value={slot} className="bg-[#151515] text-white">
                          {slot}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Info Note */}
                <div className="bg-white/10 border border-white/10 rounded-xl p-3 text-[11px] text-orange-300 leading-relaxed self-end">
                  <strong>Notice:</strong> We hold tables for a maximum of 15 minutes. For parties larger than 12, please reach our events desk.
                </div>
              </div>

              {/* Special Requests */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-white/60 block flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-white/40" /> Special Requests (Optional)
                </label>
                <textarea
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white placeholder-white/20 focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200 resize-none"
                  placeholder="E.g., Birthday celebration, high-chair needed, dairy allergy..."
                  id="res-requests"
                />
              </div>

              {/* Submit */}
              <button
                type="submit"
                className="w-full bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 rounded-xl text-xs transition-all duration-300 shadow-md cursor-pointer text-center"
              >
                Confirm Booking Request
              </button>
            </form>
          )}
        </AnimatePresence>
      </div>

      {/* Your Bookings Sidebar (2 Columns) */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-6 h-full flex flex-col text-white">
          <h4 className="font-serif text-lg font-bold text-white pb-3 border-b border-white/10 mb-4">
            Active Reservations
          </h4>

          {reservations.length === 0 ? (
            <div className="my-auto py-12 text-center space-y-2">
              <Calendar className="w-8 h-8 text-white/20 mx-auto" />
              <p className="text-white/60 text-xs">No reservations scheduled.</p>
              <p className="text-white/40 text-[10px] max-w-xs mx-auto">
                Once you submit a reservation request, it will appear here for tracking and cancellation.
              </p>
            </div>
          ) : (
            <div className="space-y-4 overflow-y-auto max-h-[30rem] pr-1 flex-1">
              <AnimatePresence mode="popLayout">
                {reservations.map((res) => (
                  <div
                    key={res.id}
                    className="bg-white/5 border border-white/10 rounded-2xl p-4 shadow-sm relative group"
                    id={`res-card-${res.id}`}
                  >
                    <button
                      onClick={() => cancelReservation(res.id)}
                      className="absolute top-4 right-4 text-white/40 hover:text-red-400 transition-colors cursor-pointer"
                      title="Cancel Reservation"
                      id={`cancel-res-${res.id}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <div className="space-y-3">
                      <div>
                        <h5 className="font-semibold text-white text-xs pr-6 truncate">{res.name}</h5>
                        <p className="text-white/40 text-[10px]">{res.email}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px] text-white/60 font-medium">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-orange-400" />
                          <span>{res.date}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-orange-400" />
                          <span>{res.time}</span>
                        </div>
                        <div className="flex items-center gap-1 col-span-2">
                          <Users className="w-3.5 h-3.5 text-orange-400" />
                          <span>{res.guests} {res.guests === 1 ? "Person" : "People"}</span>
                        </div>
                      </div>

                      {res.specialRequests && (
                        <div className="bg-white/5 rounded-lg p-2 text-[10px] text-white/60 leading-relaxed border border-white/5">
                          <strong>Notes:</strong> {res.specialRequests}
                        </div>
                      )}

                      <div className="flex justify-between items-center pt-2 border-t border-white/5">
                        <span className="text-[10px] text-white/40">
                          Table Assigned: <span className="font-mono font-bold text-white">#{res.tableNumber}</span>
                        </span>
                        <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/10 text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                          {res.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
