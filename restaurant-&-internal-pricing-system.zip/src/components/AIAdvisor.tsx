import React, { useState, useRef, useEffect } from "react";
import { Ingredient, Dish, AIAdvisorResponse } from "../types";
import { 
  Bot, 
  Sparkles, 
  ChevronRight, 
  Play, 
  Send, 
  RefreshCw, 
  User, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle,
  HelpCircle as QuestionIcon
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AIAdvisorProps {
  ingredients: Ingredient[];
  dishes: Dish[];
}

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
}

export default function AIAdvisor({ ingredients, dishes }: AIAdvisorProps) {
  // Audit States
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("");
  const [auditResponse, setAuditResponse] = useState<AIAdvisorResponse | null>(null);
  const [auditError, setAuditError] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState("");

  // Chat States
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "welcome_msg",
      role: "assistant",
      content: "Hello! I am your AI Restaurant Financial Advisor. You can ask me questions about your recipe costs, ingredient substitutions, pricing psychology, or how to buffer against rising inflation. How can I help optimize your margins today?",
    }
  ]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, chatLoading]);

  // Loading statements for audit simulation
  const loadingStatements = [
    "Compiling current Back of House ingredient cost vectors...",
    "Correlating recipe quantities against market volatility index...",
    "Auditing margin thresholds and cost-of-goods-sold (COGS)...",
    "Running menu optimization recommendations via Gemini...",
    "Formatting strategic financial report..."
  ];

  const triggerAudit = async () => {
    setLoadingAudit(true);
    setAuditError(null);
    let statementIndex = 0;
    setLoadingMessage(loadingStatements[0]);

    // Cycle through loading statements for nice UX
    const interval = setInterval(() => {
      statementIndex = (statementIndex + 1) % loadingStatements.length;
      setLoadingMessage(loadingStatements[statementIndex]);
    }, 2000);

    try {
      const response = await fetch("/api/pricing/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dishes,
          ingredients,
          customContext: customPrompt.trim() || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error("Advisor API returned an error status.");
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.message || "Failed to generate advice.");
      }

      setAuditResponse(data);
    } catch (err: any) {
      console.error(err);
      setAuditError(err.message || "Something went wrong while auditing the menu. Please make sure your Gemini API key is configured.");
    } finally {
      clearInterval(interval);
      setLoadingAudit(false);
    }
  };

  const sendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: chatInput.trim(),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setChatInput("");
    setChatLoading(true);

    try {
      const updatedMessages = [...chatMessages, userMsg].map((m) => ({
        role: m.role,
        content: m.content
      }));

      const response = await fetch("/api/pricing/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedMessages,
          dishes,
          ingredients,
        }),
      });

      if (!response.ok) {
        throw new Error("Chat API failed.");
      }

      const data = await response.json();
      
      setChatMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: data.content || "I apologize, I encountered an issue analyzing your request.",
        },
      ]);
    } catch (err: any) {
      console.error(err);
      setChatMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "I'm having trouble connecting to the advisory servers. Please make sure the Gemini API secret key is active in the Secrets menu.",
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  // Helper to format custom markdown-like text
  const formatText = (text: string) => {
    return text.split("\n").map((line, i) => {
      const cleanLine = line.trim();
      if (cleanLine.startsWith("###")) {
        return <h5 key={i} className="text-sm font-serif font-bold text-white mt-3 mb-1.5">{cleanLine.replace("###", "")}</h5>;
      }
      if (cleanLine.startsWith("##")) {
        return <h4 key={i} className="text-base font-serif font-bold text-orange-400 mt-4 mb-2">{cleanLine.replace("##", "")}</h4>;
      }
      if (cleanLine.startsWith("* ") || cleanLine.startsWith("- ")) {
        return <li key={i} className="text-xs text-white/60 leading-relaxed ml-4 list-disc mb-1">{cleanLine.substring(2)}</li>;
      }
      if (cleanLine === "") return <div key={i} className="h-2" />;
      
      // Bold rendering fallback
      return <p key={i} className="text-xs text-white/70 leading-relaxed mb-2">{cleanLine}</p>;
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Menu Audit Column (7 Columns) */}
      <div className="lg:col-span-7 space-y-6">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-6 md:p-8 space-y-6 shadow-xs rounded-3xl text-white">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-wider text-orange-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-orange-400 animate-pulse" /> Advanced Machine Consulting
              </span>
              <h3 className="font-serif text-2xl font-bold text-white">AI Menu Optimization Audit</h3>
              <p className="text-white/65 text-xs leading-relaxed">
                Generate an in-depth financial audit of your current recipe matrix. Our models evaluate food costs, flag sub-optimal profit margins, and recommend strategic pricing adjustments.
              </p>
            </div>
          </div>

          {/* Audit Inputs */}
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-white/60 block">Custom Focus / Directives (Optional)</label>
              <textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                rows={2}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-xs text-white placeholder-white/20 focus:bg-white/10 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-hidden transition-all duration-200"
                placeholder="E.g., Evaluate if raising the Gold Sovereign Ribeye price is safer than reducing beef portion size. Our target food cost percentage is 28%."
                id="audit-focus-input"
              />
            </div>

            <button
              onClick={triggerAudit}
              disabled={loadingAudit}
              className="w-full bg-orange-500 hover:bg-orange-600 disabled:bg-orange-500/50 text-white font-semibold py-3 rounded-xl text-xs transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-md"
              id="run-audit-btn"
            >
              {loadingAudit ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Analyzing Menu...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Analyze & Optimize Menu Pricing
                </>
              )}
            </button>
          </div>

          {/* Audit Results Render */}
          <AnimatePresence mode="wait">
            {loadingAudit && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="border border-white/10 rounded-2xl p-8 text-center space-y-4 bg-white/5"
                id="audit-loading-screen"
              >
                <div className="w-12 h-12 rounded-full border-2 border-orange-500 border-t-transparent animate-spin mx-auto" />
                <div className="space-y-1.5">
                  <h4 className="font-serif text-sm font-semibold text-white">Auditing Recipe Profitability</h4>
                  <p className="text-[11px] text-orange-300 font-medium animate-pulse">{loadingMessage}</p>
                </div>
              </motion.div>
            )}

            {auditError && !loadingAudit && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-5 text-center text-xs text-rose-300 space-y-2"
                id="audit-error-screen"
              >
                <AlertTriangle className="w-6 h-6 text-rose-400 mx-auto" />
                <p className="font-semibold">Audit Execution Failed</p>
                <p className="max-w-md mx-auto text-[11px] leading-relaxed text-rose-300/80">{auditError}</p>
              </motion.div>
            )}

            {auditResponse && !loadingAudit && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6 pt-4 border-t border-white/10"
                id="audit-results-screen"
              >
                {/* Executive Summary */}
                <div className="space-y-2 bg-white/5 border border-white/10 p-4 rounded-2xl text-white">
                  <h4 className="font-serif text-sm font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Executive Audit Analysis
                  </h4>
                  <div className="text-white/80 text-xs leading-relaxed space-y-2">
                    {formatText(auditResponse.analysis)}
                  </div>
                </div>

                {/* Specific Recipe Recommendations */}
                <div className="space-y-3">
                  <h4 className="font-serif text-sm font-bold text-white">Recommended Recipe Decisions</h4>
                  <div className="space-y-3">
                    {auditResponse.suggestions.map((suggestion, i) => (
                      <div key={i} className="border border-white/5 rounded-2xl p-4 space-y-3 bg-white/5 hover:border-white/10 hover:shadow-sm transition-all text-white">
                        <div className="flex justify-between items-start gap-4">
                          <div>
                            <h5 className="font-serif text-xs font-bold text-white">{suggestion.dishName}</h5>
                            <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm inline-block mt-1 ${
                              suggestion.action === "Raise Price" ? "bg-rose-500/10 text-rose-300 border border-rose-500/20" :
                              suggestion.action === "Substitute Ingredient" ? "bg-amber-500/10 text-amber-300 border border-amber-500/20" :
                              "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                            }`}>
                              {suggestion.action}
                            </span>
                          </div>
                          <div className="text-right text-xs">
                            <div className="text-white/40 text-[10px]">RECOM PRICE</div>
                            <div className="font-mono font-bold text-orange-400 text-sm">${suggestion.recommendedPrice.toFixed(2)}</div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 bg-white/5 border border-white/5 rounded-xl p-2.5 text-[10px] text-white/50 font-medium">
                          <div>Current Cost: <span className="font-mono text-white/80 font-semibold">${suggestion.currentCost.toFixed(2)}</span></div>
                          <div>Current Margin: <span className="font-mono text-white/80 font-semibold">{suggestion.currentMargin.toFixed(0)}%</span></div>
                        </div>

                        <p className="text-[11px] text-white/60 leading-relaxed">{suggestion.details}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Outlook Section */}
                <div className="pt-4 border-t border-white/10 space-y-2">
                  <h4 className="font-serif text-sm font-bold text-white">Pricing Psychology & Market Outlook</h4>
                  <div className="text-xs text-white/80 leading-relaxed space-y-2">
                    {formatText(auditResponse.marketOutlook)}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Strategic Advisor Chatbot (5 Columns) */}
      <div className="lg:col-span-5 h-[36rem] lg:h-full">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 text-white rounded-3xl p-6 flex flex-col justify-between h-[36rem] lg:min-h-[42rem]">
          {/* Top Info Header */}
          <div className="flex items-center gap-3 pb-4 border-b border-white/10">
            <div className="p-2 bg-white/10 text-orange-400 border border-white/5 rounded-xl">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-serif text-sm font-bold text-white">AI Financial Consultant</h4>
              <p className="text-white/40 text-[10px] flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" /> Active Strategy Terminal
              </p>
            </div>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 scrollbar-thin scrollbar-thumb-white/10">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 text-xs ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
                id={`chat-msg-${msg.id}`}
              >
                {msg.role === "assistant" && (
                  <div className="w-7 h-7 rounded-full bg-white/5 border border-white/10 text-orange-400 flex items-center justify-center shrink-0 self-end">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`p-3.5 rounded-2xl max-w-[85%] leading-relaxed ${
                    msg.role === "user"
                      ? "bg-orange-500 text-white rounded-br-none"
                      : "bg-white/10 border border-white/5 text-white/90 rounded-bl-none"
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === "user" && (
                  <div className="w-7 h-7 rounded-full bg-orange-600 text-white flex items-center justify-center shrink-0 self-end">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {chatLoading && (
              <div className="flex gap-3 text-xs justify-start" id="chat-loading-indicator">
                <div className="w-7 h-7 rounded-full bg-white/5 border border-white/10 text-orange-400 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 animate-bounce" />
                </div>
                <div className="p-3.5 bg-white/10 border border-white/5 text-white/60 rounded-2xl rounded-bl-none flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-orange-400" />
                  Advisor is analyzing your dish variables...
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Chat Inputs */}
          <form onSubmit={sendChatMessage} className="pt-4 border-t border-white/10 flex gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              disabled={chatLoading}
              placeholder="Ask about costing, inflation or recipe substitutes..."
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-white outline-hidden focus:bg-white/10 focus:border-orange-500 transition-colors placeholder-white/20"
              id="chat-input-field"
            />
            <button
              type="submit"
              disabled={chatLoading || !chatInput.trim()}
              className="bg-orange-500 hover:bg-orange-600 disabled:bg-white/5 disabled:text-white/20 text-white p-2.5 rounded-xl transition-all flex items-center justify-center shrink-0 cursor-pointer"
              id="send-chat-btn"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
