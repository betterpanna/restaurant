import React, { useState, useEffect } from "react";
import { Ingredient, Dish, Reservation, OrderItem } from "./types";
import { INITIAL_INGREDIENTS, INITIAL_DISHES } from "./data";
import CustomerMenu from "./components/CustomerMenu";
import ReservationForm from "./components/ReservationForm";
import PricingDashboard from "./components/PricingDashboard";
import AIAdvisor from "./components/AIAdvisor";
import { 
  Utensils, 
  Calendar, 
  Settings, 
  Sparkles, 
  Info, 
  TrendingUp,
  Sliders,
  DollarSign,
  Heart
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Tabs: "menu" | "reservations" | "dashboard" | "advisor"
  const [activeTab, setActiveTab] = useState<"menu" | "reservations" | "dashboard" | "advisor">("menu");

  // Core Data States
  const [ingredients, setIngredients] = useState<Ingredient[]>(INITIAL_INGREDIENTS);
  const [dishes, setDishes] = useState<Dish[]>(INITIAL_DISHES);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);

  // Load and seed reservations
  useEffect(() => {
    const saved = localStorage.getItem("savor_scale_reservations");
    if (saved) {
      setReservations(JSON.parse(saved));
    } else {
      // Seed two beautiful initial reservations for realistic display
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const dayAfter = new Date();
      dayAfter.setDate(dayAfter.getDate() + 2);

      const seedReservations: Reservation[] = [
        {
          id: "res_seed_1",
          name: "Eleanor Vance",
          email: "eleanor.vance@example.com",
          phone: "(415) 392-0193",
          date: tomorrow.toISOString().split("T")[0],
          time: "19:30",
          guests: 4,
          specialRequests: "Window table overlooking the patio, celebrating a 30th birthday.",
          status: "Confirmed",
          tableNumber: 12,
        },
        {
          id: "res_seed_2",
          name: "Julian Mercer",
          email: "julian@mercerconsulting.com",
          phone: "(212) 834-9241",
          date: dayAfter.toISOString().split("T")[0],
          time: "20:00",
          guests: 2,
          specialRequests: "Strict gluten allergy for one guest.",
          status: "Confirmed",
          tableNumber: 4,
        }
      ];
      setReservations(seedReservations);
      localStorage.setItem("savor_scale_reservations", JSON.stringify(seedReservations));
    }
  }, []);

  // Sync reservations to localStorage
  const saveReservations = (newReservations: Reservation[]) => {
    setReservations(newReservations);
    localStorage.setItem("savor_scale_reservations", JSON.stringify(newReservations));
  };

  // 1. Cost & Menu State Modifiers
  const updateIngredientCost = (id: string, newCost: number) => {
    setIngredients((prev) =>
      prev.map((ing) => (ing.id === id ? { ...ing, costPerUnit: Math.max(0, newCost) } : ing))
    );
  };

  const updateDishMenuPrice = (id: string, newPrice: number) => {
    setDishes((prev) =>
      prev.map((dish) => (dish.id === id ? { ...dish, menuPrice: Math.max(0, newPrice) } : dish))
    );
  };

  const resetAllCosts = () => {
    setIngredients(INITIAL_INGREDIENTS);
    setDishes(INITIAL_DISHES);
  };

  const applyEconomicShock = (multiplier: number, category?: string) => {
    setIngredients((prev) =>
      prev.map((ing) => {
        if (!category || ing.category === category) {
          return { ...ing, costPerUnit: parseFloat((ing.costPerUnit * multiplier).toFixed(2)) };
        }
        return ing;
      })
    );
  };

  // 2. Reservation Handlers
  const addReservation = (booking: Omit<Reservation, "id" | "status" | "tableNumber">) => {
    const newBooking: Reservation = {
      ...booking,
      id: "res_" + Math.random().toString(36).substr(2, 9),
      status: "Confirmed",
      tableNumber: Math.floor(Math.random() * 20) + 1,
    };
    const updated = [newBooking, ...reservations];
    saveReservations(updated);
  };

  const cancelReservation = (id: string) => {
    const updated = reservations.filter((res) => res.id !== id);
    saveReservations(updated);
  };

  // 3. Ticket / Order Handlers
  const addToOrder = (dish: Dish) => {
    setOrderItems((prev) => {
      const existing = prev.find((item) => item.dishId === dish.id);
      if (existing) {
        return prev.map((item) =>
          item.dishId === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          id: "item_" + Math.random().toString(36).substr(2, 9),
          dishId: dish.id,
          name: dish.name,
          price: dish.menuPrice,
          quantity: 1,
        },
      ];
    });
  };

  const updateOrderQuantity = (id: string, delta: number) => {
    setOrderItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const nextQuantity = item.quantity + delta;
            return { ...item, quantity: nextQuantity };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromOrder = (id: string) => {
    setOrderItems((prev) => prev.filter((item) => item.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col font-sans relative overflow-hidden">
      {/* Mesh Gradient Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-orange-600/20 rounded-full blur-[120px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-amber-500/10 rounded-full blur-[150px] pointer-events-none z-0"></div>

      {/* 1. Header Navigation Bar */}
      <header className="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-tr from-orange-500 to-amber-300 text-white p-2.5 rounded-2xl flex items-center justify-center shadow-md">
                <Utensils className="w-5.5 h-5.5" />
              </div>
              <div>
                <span className="font-serif text-xl font-bold tracking-tight text-white">
                  Savor <span className="text-orange-400 font-normal italic">&amp; Scale</span>
                </span>
                <span className="text-[10px] font-mono text-white/40 block tracking-wider uppercase">
                  Modern Bistro &amp; Pricing Simulator
                </span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex gap-1 bg-white/5 p-1 rounded-full border border-white/10">
              <button
                onClick={() => setActiveTab("menu")}
                className={`px-5 py-2 rounded-full text-xs font-semibold transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "menu"
                    ? "bg-white/15 text-orange-400 border border-white/10 shadow-xs"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
                id="tab-btn-menu"
              >
                <Utensils className="w-3.5 h-3.5" />
                Culinary Menu
              </button>
              <button
                onClick={() => setActiveTab("reservations")}
                className={`px-5 py-2 rounded-full text-xs font-semibold transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "reservations"
                    ? "bg-white/15 text-orange-400 border border-white/10 shadow-xs"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
                id="tab-btn-reservations"
              >
                <Calendar className="w-3.5 h-3.5" />
                Table Bookings
              </button>
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`px-5 py-2 rounded-full text-xs font-semibold transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "dashboard"
                    ? "bg-white/15 text-orange-400 border border-white/10 shadow-xs"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
                id="tab-btn-dashboard"
              >
                <Sliders className="w-3.5 h-3.5" />
                Admin Pricing Console
              </button>
              <button
                onClick={() => setActiveTab("advisor")}
                className={`px-5 py-2 rounded-full text-xs font-semibold transition-all duration-300 flex items-center gap-1.5 cursor-pointer ${
                  activeTab === "advisor"
                    ? "bg-white/15 text-orange-400 border border-white/10 shadow-xs"
                    : "text-white/60 hover:text-white hover:bg-white/5"
                }`}
                id="tab-btn-advisor"
              >
                <Sparkles className="w-3.5 h-3.5" />
                AI Consultant
              </button>
            </nav>

            {/* Portal Indicator */}
            <div className="flex items-center gap-2">
              <span className="hidden lg:inline-flex bg-white/10 text-white/90 text-[10px] font-bold px-3 py-1 rounded-full border border-white/10 uppercase tracking-wider">
                {activeTab === "dashboard" || activeTab === "advisor" ? "Staff Access Active" : "Guest Mode"}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Bar */}
      <div className="md:hidden bg-white/5 border-b border-white/10 p-2 flex justify-around sticky top-20 z-30 backdrop-blur-md text-white">
        <button
          onClick={() => setActiveTab("menu")}
          className={`flex-1 py-2 text-center flex flex-col items-center gap-1 text-[10px] font-bold ${
            activeTab === "menu" ? "text-orange-400" : "text-white/40"
          }`}
        >
          <Utensils className="w-4.5 h-4.5" />
          Menu
        </button>
        <button
          onClick={() => setActiveTab("reservations")}
          className={`flex-1 py-2 text-center flex flex-col items-center gap-1 text-[10px] font-bold ${
            activeTab === "reservations" ? "text-orange-400" : "text-white/40"
          }`}
        >
          <Calendar className="w-4.5 h-4.5" />
          Bookings
        </button>
        <button
          onClick={() => setActiveTab("dashboard")}
          className={`flex-1 py-2 text-center flex flex-col items-center gap-1 text-[10px] font-bold ${
            activeTab === "dashboard" ? "text-orange-400" : "text-white/40"
          }`}
        >
          <Sliders className="w-4.5 h-4.5" />
          Admin
        </button>
        <button
          onClick={() => setActiveTab("advisor")}
          className={`flex-1 py-2 text-center flex flex-col items-center gap-1 text-[10px] font-bold ${
            activeTab === "advisor" ? "text-orange-400" : "text-white/40"
          }`}
        >
          <Sparkles className="w-4.5 h-4.5" />
          AI Consult
        </button>
      </div>

      {/* 2. Hero banner section (Guest view or Admin contextual header) */}
      <div className="relative overflow-hidden bg-white/5 border-b border-white/10 z-10">
        {/* Background Image with culinary vibe */}
        <div className="absolute inset-0 z-0 opacity-10">
          <img
            src="https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&q=80&w=1600"
            alt="Atmospheric Restaurant Interior"
            className="w-full h-full object-cover filter blur-xs"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-[#0a0a0a]/90 to-transparent" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-16 relative z-10">
          <div className="max-w-2xl space-y-4">
            <span className="text-orange-400 text-xs font-bold uppercase tracking-widest block">
              {activeTab === "menu" || activeTab === "reservations" 
                ? "The Sovereign Culinary Suite" 
                : "Restaurant Economics Terminal"}
            </span>

            <h1 className="font-serif text-3xl md:text-5xl font-bold tracking-tight leading-none text-white">
              {activeTab === "menu" && (
                <>Fine Dining <span className="font-normal italic text-orange-400">Reimagined</span></>
              )}
              {activeTab === "reservations" && (
                <>Reserve Your <span className="font-normal italic text-orange-400">Exclusive Table</span></>
              )}
              {activeTab === "dashboard" && (
                <>Back of House <span className="font-normal italic text-orange-400">Pricing Engine</span></>
              )}
              {activeTab === "advisor" && (
                <>AI Menu Engineering <span className="font-normal italic text-orange-400">Advisor</span></>
              )}
            </h1>

            <p className="text-white/60 text-xs md:text-sm leading-relaxed">
              {activeTab === "menu" && "Indulge in a sensory voyage crafted by our master chefs. Each dish combines premium artisanal ingredients, culinary technique, and sophisticated flavor architectures."}
              {activeTab === "reservations" && "Schedule an unforgettable sensory experience. Secure your seating arrangements inside our grand dining lounge, complete with customizable chef directives."}
              {activeTab === "dashboard" && "Adjust Back of House ingredient costs, trigger inflation sweeps, and optimize menu prices dynamically. Monitor food cost percentages and gross margins instantly."}
              {activeTab === "advisor" && "Leverage state-of-the-art Gemini intelligence to audit your recipe costs, analyze menu vulnerability indices, and chat directly with a senior restaurant consultant."}
            </p>
          </div>
        </div>
      </div>

      {/* 3. Main Dynamic View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
            className="focus:outline-none"
          >
            {activeTab === "menu" && (
              <CustomerMenu
                dishes={dishes}
                addToOrder={addToOrder}
                orderItems={orderItems}
                updateOrderQuantity={updateOrderQuantity}
                removeFromOrder={removeFromOrder}
              />
            )}

            {activeTab === "reservations" && (
              <ReservationForm
                reservations={reservations}
                addReservation={addReservation}
                cancelReservation={cancelReservation}
              />
            )}

            {activeTab === "dashboard" && (
              <PricingDashboard
                ingredients={ingredients}
                dishes={dishes}
                updateIngredientCost={updateIngredientCost}
                updateDishMenuPrice={updateDishMenuPrice}
                resetAllCosts={resetAllCosts}
                applyEconomicShock={applyEconomicShock}
              />
            )}

            {activeTab === "advisor" && (
              <AIAdvisor
                ingredients={ingredients}
                dishes={dishes}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 4. Elegant Editorial Footer */}
      <footer className="bg-[#0a0a0a]/80 backdrop-blur-xl border-t border-white/10 py-12 mt-auto z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <span className="font-serif text-lg font-bold text-white">
              Savor <span className="text-orange-400 font-normal italic">&amp; Scale</span>
            </span>
            <p className="text-white/40 text-xs leading-relaxed">
              Bridging master-class culinary experiences with precision financial engineering. Built for the modern epicurean entrepreneur.
            </p>
          </div>

          <div className="space-y-2">
            <h5 className="font-serif text-xs font-bold uppercase tracking-wider text-white">Our Location &amp; Hours</h5>
            <p className="text-white/60 text-xs leading-relaxed">
              492 Sovereign Boulevard, Metropolis<br />
              Dinner Service: 17:00 – 23:00 Daily
            </p>
          </div>

          <div className="space-y-2">
            <h5 className="font-serif text-xs font-bold uppercase tracking-wider text-white">Operational Integrity</h5>
            <p className="text-white/60 text-xs leading-relaxed">
              Our back-of-house costing algorithms utilize real-time price index matrices, helping bistro managers remain resilient in volatile economies.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 mt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-white/40 font-mono">
          <span>&copy; {new Date().getFullYear()} Savor &amp; Scale LLC. All rights reserved.</span>
          <span className="flex items-center gap-1">
            Made with <Heart className="w-3 h-3 text-orange-500 fill-orange-500" /> for Gastronomy Management
          </span>
        </div>
      </footer>
    </div>
  );
}
