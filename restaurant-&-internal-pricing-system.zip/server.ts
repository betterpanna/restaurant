import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

let aiClient: GoogleGenAI | null = null;

function getAIClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // 1. Endpoint: Structured AI Pricing Advisor
  app.post("/api/pricing/advisor", async (req, res) => {
    try {
      const { dishes, ingredients, customContext } = req.body;
      const ai = getAIClient();

      const systemPrompt = `You are a Senior Restaurant Consultant and Pricing Strategist.
Your goal is to analyze the menu items (dishes) and current market cost of ingredients, calculate the cost of goods sold (COGS), food cost percentage (Target: 25-35%), and propose pricing adjustments or costing strategies.
Be realistic, analytical, and professional. Ensure that your recommendations represent expert level financial consulting for a modern restaurant owner.`;

      const prompt = `Here is the current list of dishes and ingredients.
      
Ingredients Database:
${JSON.stringify(ingredients, null, 2)}

Menu Dishes with Recipe Ingredients and Menu Prices:
${JSON.stringify(dishes, null, 2)}

User Custom Request / Context:
${customContext || "Generate an overall financial audit of the menu and suggest optimal prices for maximum gross margins."}

Please analyze each dish and output the results as a JSON object matching the provided schema. Highlight high-cost vulnerabilities, and recommend menu adjustments.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: systemPrompt,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              analysis: {
                type: Type.STRING,
                description: "Executive strategic summary of overall financial health and pricing recommendations"
              },
              suggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    dishId: { type: Type.STRING },
                    dishName: { type: Type.STRING },
                    currentCost: { type: Type.NUMBER, description: "Calculated recipe cost based on ingredients" },
                    currentMargin: { type: Type.NUMBER, description: "Calculated Gross Profit Margin percentage (0 to 100)" },
                    recommendedPrice: { type: Type.NUMBER, description: "Suggested new menu price" },
                    action: { type: Type.STRING, description: "Recommended action: 'Raise Price', 'Reduce Portion', 'Substitute Ingredient', or 'Keep Price'" },
                    details: { type: Type.STRING, description: "Specific strategic rationale for this change" }
                  },
                  required: ["dishId", "dishName", "currentCost", "currentMargin", "recommendedPrice", "action", "details"]
                }
              },
              marketOutlook: {
                type: Type.STRING,
                description: "Pricing psychology, marketing ideas, or cost of goods sold strategy to improve margins"
              }
            },
            required: ["analysis", "suggestions", "marketOutlook"]
          }
        }
      });

      const responseText = response.text || "{}";
      res.json(JSON.parse(responseText.trim()));
    } catch (error: any) {
      console.error("Pricing Advisor Error:", error);
      res.status(500).json({ 
        error: "Failed to generate AI advice", 
        message: error.message || "Unknown error" 
      });
    }
  });

  // 2. Endpoint: AI Consultant Chat Interface
  app.post("/api/pricing/chat", async (req, res) => {
    try {
      const { messages, dishes, ingredients } = req.body;
      const ai = getAIClient();

      const systemPrompt = `You are a conversational Senior Restaurant Consultant chatbot. 
You advise restaurant owners on menu engineering, dish costing, pricing strategies, market positioning, and kitchen efficiency.
Refer to their current menu and ingredients to ground your advice.

Current Ingredients Database:
${JSON.stringify(ingredients, null, 2)}

Current Menu Items:
${JSON.stringify(dishes, null, 2)}

Keep responses concise, actionable, friendly, and deeply professional. Avoid generic answers. Give specific culinary and pricing suggestions!`;

      // Map messages to Gemini Content parts
      const contents = messages.map((m: any) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: contents,
        config: {
          systemInstruction: systemPrompt,
        }
      });

      res.json({ content: response.text });
    } catch (error: any) {
      console.error("Consultant Chat Error:", error);
      res.status(500).json({ 
        error: "Failed to chat with AI Consultant", 
        message: error.message || "Unknown error" 
      });
    }
  });

  // Vite Integration for Assets Serving
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
